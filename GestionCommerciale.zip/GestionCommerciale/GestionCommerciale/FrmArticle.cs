﻿using GestionCommerciale.Entity;
using GestionCommerciale.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionCommerciale
{
    public partial class FrmArticle : Form
    {

        private GesComServices service = new GesComServices();
        private List<Article> articles;
       // Categorie categorieSelect;
        public FrmArticle()
        {
            InitializeComponent();
        }

        private void FrmArticle_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'gesCom.Article'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.articleTableAdapter.Fill(this.gesCom.Article);
            // TODO: cette ligne de code charge les données dans la table 'gestionComDataSet1.Categorie'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.categorieTableAdapter.Fill(this.gestionComDataSet1.Categorie);


        }

        private void btnAddArticle_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtRef.Text) || string.IsNullOrEmpty(txtCategorie.Text) || string.IsNullOrEmpty(txtLibelle.Text) || string.IsNullOrEmpty(txtPrix.Text) || string.IsNullOrEmpty(txtStock.Text))
            {
                MessageBox.Show("Veuillez remplir tous les champs", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            { 
                Article art = new Article()
                {
                    Reference = txtRef.Text,
                    Categorie = txtCategorie.Text,
                    Libelle = txtLibelle.Text,
                    Prix = int.Parse(txtPrix.Text),
                    Stock = int.Parse(txtStock.Text)               
                };
                if (service.AddArticle(art))
                {
                    MessageBox.Show("Article Ajouté avec succes ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.articleTableAdapter.Fill(this.gesCom.Article);
                }
            }           
        }

       

        private void btnClose_Click(object sender, EventArgs e)
        {

        }
    }
}
