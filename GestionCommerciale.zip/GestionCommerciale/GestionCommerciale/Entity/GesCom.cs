﻿namespace GestionCommerciale.Entity
{
}

namespace GestionCommerciale.Entity
{


    public partial class GesCom
    {
    }
}
namespace GestionCommerciale.Entity {
    
    
    public partial class GesCom {
    }
}
