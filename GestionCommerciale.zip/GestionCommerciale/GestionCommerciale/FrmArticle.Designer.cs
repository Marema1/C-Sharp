﻿namespace GestionCommerciale
{
    partial class FrmArticle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.categorieBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gestionComDataSet1 = new GestionCommerciale.GestionComDataSet1();
            this.categorieTableAdapter = new GestionCommerciale.GestionComDataSet1TableAdapters.CategorieTableAdapter();
            this.articleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.articleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.articleBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewAr = new System.Windows.Forms.DataGridView();
            this.idArticleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.libelleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prixDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.referenceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categorieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articleBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.gesCom = new GestionCommerciale.Entity.GesCom();
            this.label7 = new System.Windows.Forms.Label();
            this.articleBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAddArticle = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCategorie = new System.Windows.Forms.ComboBox();
            this.txtPrix = new System.Windows.Forms.TextBox();
            this.txtStock = new System.Windows.Forms.TextBox();
            this.txtLibelle = new System.Windows.Forms.TextBox();
            this.txtRef = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.articleTableAdapter = new GestionCommerciale.Entity.GesComTableAdapters.ArticleTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.categorieBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gestionComDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gesCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // categorieBindingSource
            // 
            this.categorieBindingSource.DataMember = "Categorie";
            this.categorieBindingSource.DataSource = this.gestionComDataSet1;
            // 
            // gestionComDataSet1
            // 
            this.gestionComDataSet1.DataSetName = "GestionComDataSet1";
            this.gestionComDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // categorieTableAdapter
            // 
            this.categorieTableAdapter.ClearBeforeFill = true;
            // 
            // articleBindingSource
            // 
            this.articleBindingSource.DataMember = "Article";
            // 
            // articleBindingSource1
            // 
            this.articleBindingSource1.DataMember = "Article";
            // 
            // articleBindingSource2
            // 
            this.articleBindingSource2.DataMember = "Article";
            // 
            // dataGridViewAr
            // 
            this.dataGridViewAr.AutoGenerateColumns = false;
            this.dataGridViewAr.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewAr.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAr.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewAr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAr.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idArticleDataGridViewTextBoxColumn,
            this.libelleDataGridViewTextBoxColumn,
            this.prixDataGridViewTextBoxColumn,
            this.referenceDataGridViewTextBoxColumn,
            this.stockDataGridViewTextBoxColumn,
            this.categorieDataGridViewTextBoxColumn});
            this.dataGridViewAr.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.dataGridViewAr.DataSource = this.articleBindingSource4;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewAr.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewAr.EnableHeadersVisualStyles = false;
            this.dataGridViewAr.Location = new System.Drawing.Point(162, 45);
            this.dataGridViewAr.Name = "dataGridViewAr";
            this.dataGridViewAr.Size = new System.Drawing.Size(479, 302);
            this.dataGridViewAr.TabIndex = 17;
            this.dataGridViewAr.UseWaitCursor = true;
            // 
            // idArticleDataGridViewTextBoxColumn
            // 
            this.idArticleDataGridViewTextBoxColumn.DataPropertyName = "Id_Article";
            this.idArticleDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idArticleDataGridViewTextBoxColumn.MaxInputLength = 3276;
            this.idArticleDataGridViewTextBoxColumn.Name = "idArticleDataGridViewTextBoxColumn";
            this.idArticleDataGridViewTextBoxColumn.ReadOnly = true;
            this.idArticleDataGridViewTextBoxColumn.Width = 75;
            // 
            // libelleDataGridViewTextBoxColumn
            // 
            this.libelleDataGridViewTextBoxColumn.DataPropertyName = "Libelle";
            this.libelleDataGridViewTextBoxColumn.HeaderText = "Libelle";
            this.libelleDataGridViewTextBoxColumn.Name = "libelleDataGridViewTextBoxColumn";
            // 
            // prixDataGridViewTextBoxColumn
            // 
            this.prixDataGridViewTextBoxColumn.DataPropertyName = "Prix";
            this.prixDataGridViewTextBoxColumn.HeaderText = "Prix";
            this.prixDataGridViewTextBoxColumn.Name = "prixDataGridViewTextBoxColumn";
            this.prixDataGridViewTextBoxColumn.Width = 50;
            // 
            // referenceDataGridViewTextBoxColumn
            // 
            this.referenceDataGridViewTextBoxColumn.DataPropertyName = "Reference";
            this.referenceDataGridViewTextBoxColumn.HeaderText = "Reference";
            this.referenceDataGridViewTextBoxColumn.Name = "referenceDataGridViewTextBoxColumn";
            this.referenceDataGridViewTextBoxColumn.Width = 75;
            // 
            // stockDataGridViewTextBoxColumn
            // 
            this.stockDataGridViewTextBoxColumn.DataPropertyName = "Stock";
            this.stockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.stockDataGridViewTextBoxColumn.Name = "stockDataGridViewTextBoxColumn";
            this.stockDataGridViewTextBoxColumn.Width = 50;
            // 
            // categorieDataGridViewTextBoxColumn
            // 
            this.categorieDataGridViewTextBoxColumn.DataPropertyName = "Categorie";
            this.categorieDataGridViewTextBoxColumn.HeaderText = "Categorie";
            this.categorieDataGridViewTextBoxColumn.Name = "categorieDataGridViewTextBoxColumn";
            // 
            // articleBindingSource4
            // 
            this.articleBindingSource4.DataMember = "Article";
            this.articleBindingSource4.DataSource = this.gesCom;
            // 
            // gesCom
            // 
            this.gesCom.DataSetName = "GesCom";
            this.gesCom.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.label7.Location = new System.Drawing.Point(376, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 18);
            this.label7.TabIndex = 19;
            this.label7.Text = "Gestion commerciale";
            this.label7.UseWaitCursor = true;
            // 
            // articleBindingSource3
            // 
            this.articleBindingSource3.DataMember = "Article";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel6);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btnAddArticle);
            this.groupBox1.Controls.Add(this.panel5);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCategorie);
            this.groupBox1.Controls.Add(this.txtPrix);
            this.groupBox1.Controls.Add(this.txtStock);
            this.groupBox1.Controls.Add(this.txtLibelle);
            this.groupBox1.Controls.Add(this.txtRef);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Location = new System.Drawing.Point(-8, -25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 501);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.UseWaitCursor = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(69, 327);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(152, 1);
            this.panel6.TabIndex = 30;
            this.panel6.UseWaitCursor = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel7.Location = new System.Drawing.Point(0, -9);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(152, 1);
            this.panel7.TabIndex = 26;
            this.panel7.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(11, 304);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 15);
            this.label6.TabIndex = 29;
            this.label6.Text = "Categorie";
            this.label6.UseWaitCursor = true;
            // 
            // btnAddArticle
            // 
            this.btnAddArticle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.btnAddArticle.FlatAppearance.BorderSize = 0;
            this.btnAddArticle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddArticle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAddArticle.Location = new System.Drawing.Point(141, 358);
            this.btnAddArticle.Name = "btnAddArticle";
            this.btnAddArticle.Size = new System.Drawing.Size(75, 23);
            this.btnAddArticle.TabIndex = 16;
            this.btnAddArticle.Text = "Enregistrer";
            this.btnAddArticle.UseVisualStyleBackColor = false;
            this.btnAddArticle.UseWaitCursor = true;
            this.btnAddArticle.Click += new System.EventHandler(this.btnAddArticle_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel5.Location = new System.Drawing.Point(69, 268);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(152, 1);
            this.panel5.TabIndex = 28;
            this.panel5.UseWaitCursor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel4.Location = new System.Drawing.Point(71, 220);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(152, 1);
            this.panel4.TabIndex = 27;
            this.panel4.UseWaitCursor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(72, 172);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 1);
            this.panel2.TabIndex = 26;
            this.panel2.UseWaitCursor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel3.Location = new System.Drawing.Point(0, -9);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(152, 1);
            this.panel3.TabIndex = 26;
            this.panel3.UseWaitCursor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel1.Location = new System.Drawing.Point(72, 118);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(152, 1);
            this.panel1.TabIndex = 25;
            this.panel1.UseWaitCursor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(14, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 15);
            this.label5.TabIndex = 24;
            this.label5.Text = "Reference";
            this.label5.UseWaitCursor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(14, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "Libelle";
            this.label4.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(15, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 15);
            this.label3.TabIndex = 22;
            this.label3.Text = "Prix";
            this.label3.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(15, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 21;
            this.label2.Text = "Stock";
            this.label2.UseWaitCursor = true;
            // 
            // txtCategorie
            // 
            this.txtCategorie.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtCategorie.DataSource = this.categorieBindingSource;
            this.txtCategorie.DisplayMember = "Libelle";
            this.txtCategorie.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCategorie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtCategorie.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtCategorie.FormattingEnabled = true;
            this.txtCategorie.Location = new System.Drawing.Point(73, 302);
            this.txtCategorie.Name = "txtCategorie";
            this.txtCategorie.Size = new System.Drawing.Size(140, 21);
            this.txtCategorie.TabIndex = 20;
            this.txtCategorie.UseWaitCursor = true;
            this.txtCategorie.ValueMember = "Libelle";
            // 
            // txtPrix
            // 
            this.txtPrix.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtPrix.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPrix.Location = new System.Drawing.Point(61, 249);
            this.txtPrix.Name = "txtPrix";
            this.txtPrix.Size = new System.Drawing.Size(163, 13);
            this.txtPrix.TabIndex = 19;
            this.txtPrix.UseWaitCursor = true;
            // 
            // txtStock
            // 
            this.txtStock.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtStock.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtStock.Location = new System.Drawing.Point(66, 201);
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(150, 13);
            this.txtStock.TabIndex = 18;
            this.txtStock.UseWaitCursor = true;
            // 
            // txtLibelle
            // 
            this.txtLibelle.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtLibelle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLibelle.Location = new System.Drawing.Point(69, 155);
            this.txtLibelle.Name = "txtLibelle";
            this.txtLibelle.Size = new System.Drawing.Size(154, 13);
            this.txtLibelle.TabIndex = 17;
            this.txtLibelle.UseWaitCursor = true;
            // 
            // txtRef
            // 
            this.txtRef.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtRef.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRef.Location = new System.Drawing.Point(84, 101);
            this.txtRef.Multiline = true;
            this.txtRef.Name = "txtRef";
            this.txtRef.Size = new System.Drawing.Size(132, 20);
            this.txtRef.TabIndex = 16;
            this.txtRef.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.label1.Location = new System.Drawing.Point(43, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 18);
            this.label1.TabIndex = 15;
            this.label1.Text = "Enregistrement Article";
            this.label1.UseWaitCursor = true;
            // 
            // articleTableAdapter
            // 
            this.articleTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::GestionCommerciale.Properties.Resources.images__11_;
            this.pictureBox1.InitialImage = global::GestionCommerciale.Properties.Resources.images1;
            this.pictureBox1.Location = new System.Drawing.Point(627, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.UseWaitCursor = true;
            this.pictureBox1.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // FrmArticle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(653, 359);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridViewAr);
            this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.Name = "FrmArticle";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmArticle";
            this.UseWaitCursor = true;
            this.Load += new System.EventHandler(this.FrmArticle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.categorieBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gestionComDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gesCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private GestionComDataSet1 gestionComDataSet1;
        private System.Windows.Forms.BindingSource categorieBindingSource;
        private GestionComDataSet1TableAdapters.CategorieTableAdapter categorieTableAdapter;
        private System.Windows.Forms.BindingSource articleBindingSource;
        private System.Windows.Forms.BindingSource articleBindingSource1;
        private System.Windows.Forms.BindingSource articleBindingSource2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn idArticleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn libelleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prixDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource articleBindingSource3;
        private System.Windows.Forms.DataGridViewTextBoxColumn referenceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categorieDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAddArticle;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox txtCategorie;
        private System.Windows.Forms.TextBox txtPrix;
        private System.Windows.Forms.TextBox txtStock;
        private System.Windows.Forms.TextBox txtLibelle;
        private System.Windows.Forms.TextBox txtRef;
        private System.Windows.Forms.Label label1;
        private Entity.GesCom gesCom;
        private System.Windows.Forms.BindingSource articleBindingSource4;
        private Entity.GesComTableAdapters.ArticleTableAdapter articleTableAdapter;
        public System.Windows.Forms.DataGridView dataGridViewAr;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}