﻿using GestionCommerciale.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionCommerciale.Services
{
    class GesComServices
    {
        GesComModel dao = new GesComModel();

        public object User { get; internal set; }

        public GesComServices()
        {


        }
        public bool AddUser(User user)
        {
            dao.User.Add(user);
            return dao.SaveChanges() != 0;
        }
        
        public List<User> ListerUser()
        {
            return dao.User.ToList();

        }
        public bool AddArticle(Article art)
        {
            dao.Article.Add(art);
            return dao.SaveChanges() != 0;
        }

        public bool AddCommande(Commande com)
        {
            dao.Commande.Add(com);
            return dao.SaveChanges() != 0;
        }

        //  public bool AddClient(Client cli)
        // {
        //   dao.Client.Add(cli);
        //  return dao.SaveChanges() != 0;
        // }

        public void AddClient(Client cli)
        {
            dao.Client.Add(cli);
            dao.SaveChanges();

        }
        public User SeConnecter(string Login, string Password)
        {
            return dao.User.ToList().Where(
                                  u => u.Login.Trim().CompareTo(Login) == 0 &&
                                 u.Password.Trim().CompareTo(Password) == 0

                         ).FirstOrDefault();
        }

    }
}
